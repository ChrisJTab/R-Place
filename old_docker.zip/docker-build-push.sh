#!/bin/bash

# Get the directory of the script
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Change the working directory to SCRIPT_DIR
cd "${SCRIPT_DIR}" || exit


# Load configuration from the YAML file
CONFIG_FILE="docker_config.yaml"
if [ -f "$CONFIG_FILE" ]; then
    while IFS=':' read -r key value; do
        key=$(echo "$key" | tr -d '[:space:]')
        value=$(echo "$value" | tr -d '[:space:]' | tr -d '"')
        export "$key=$value"
    done < <(sed -n '/^[A-Z_]/p' "$CONFIG_FILE")
else
    echo "Error: Configuration file '$CONFIG_FILE' not found."
    exit 1
fi


AWS_REGISTRY_SERVER="${AWS_REGISTRY_ID}.dkr.ecr.${AWS_REGION}.amazonaws.com"
REGISTRY_IMAGE_ENDPOINT="${AWS_REGISTRY_SERVER}/${DOCKER_IMAGE_NAME}:${DOCKER_IMAGE_TAG}"

# Build the Docker image and tag it with the ECR repository URI
docker build -t "${REGISTRY_IMAGE_ENDPOINT}" "${SCRIPT_DIR}"

# Tag the image with the latest tag (you can customize this)
docker tag "${REGISTRY_IMAGE_ENDPOINT}" "${AWS_REGISTRY_SERVER}/${DOCKER_IMAGE_NAME}:${DOCKER_IMAGE_TAG}"

# Log in to the ECR registry
aws ecr get-login-password --region "${AWS_REGION}" | docker login --username AWS --password-stdin "${AWS_REGISTRY_SERVER}"

# Push the image to the ECR registry
docker push "${REGISTRY_IMAGE_ENDPOINT}"
