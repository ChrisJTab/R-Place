#!/bin/bash

# Get the directory of the script
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Change the working directory to SCRIPT_DIR
cd "${SCRIPT_DIR}" || exit


# Load configuration from the YAML file
CONFIG_FILE="docker_config.yaml"
if [ -f "$CONFIG_FILE" ]; then
    while IFS=':' read -r key value; do
        key=$(echo "$key" | tr -d '[:space:]')
        value=$(echo "$value" | tr -d '[:space:]' | tr -d '"')
        export "$key=$value"
    done < <(sed -n '/^[A-Z_]/p' "$CONFIG_FILE")
else
    echo "Error: Configuration file '$CONFIG_FILE' not found."
    exit 1
fi


AWS_REGISTRY_SERVER="${AWS_REGISTRY_ID}.dkr.ecr.${AWS_REGION}.amazonaws.com"
REGISTRY_IMAGE_ENDPOINT="${AWS_REGISTRY_SERVER}/${DOCKER_IMAGE_NAME}:${DOCKER_IMAGE_TAG}"


# Check if the container exists
if ! docker ps -a --format '{{.Names}}' | grep -q "^${DOCKER_CONTAINER_NAME}\$"; then
    echo "Starting Container '${DOCKER_CONTAINER_NAME}'..."
    docker run -p 8080:8080 -p 8081:8081 -d --name ${DOCKER_CONTAINER_NAME} ${REGISTRY_IMAGE_ENDPOINT}
    exit 0
fi


# Check if the container is running
if docker ps --format '{{.Names}}' | grep -q "^${DOCKER_CONTAINER_NAME}\$"; then
    echo "Container '${DOCKER_CONTAINER_NAME}' is already running."
    exit 0
fi

#echo "Starting Container '${DOCKER_CONTAINER_NAME}'..."
#docker start "${DOCKER_CONTAINER_NAME}"
